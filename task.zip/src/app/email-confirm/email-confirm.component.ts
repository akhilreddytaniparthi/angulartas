import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email-confirm',
  templateUrl: './email-confirm.component.html',
  styleUrls: ['./email-confirm.component.css']
 
})
export class EmailConfirmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
